<?php
/**
 * Template part for displaying single post
 *
 * @link https://developer.wordpress.org/themes/basics/template-hierarchy/
 *
 * @package Dtearsd Package
 * @since 1.0.0
 */


$post_data=get_queried_object();
$pID  = get_the_ID();
if (function_exists('get_fields') && function_exists('get_fields_escaped')) {
	$post_fields = get_fields_escaped( $pID );
}

// Post Tags & Categories
// $dtearsd_post_tags = get_the_tags($pID);
$dtearsd_post_categories = get_categories($pID);

$dtearsd_posttitle = dawat_page_title('dtearsd_posttitle');

// $dtearsd_posttitle = ( isset( $post_fields['dtearsd_posttitle'] ) && '' !== $post_fields['dtearsd_posttitle'] ) ? $post_fields['dtearsd_posttitle'] : get_the_title();
$dtearsd_posttext = ( isset( $post_fields['dtearsd_posttext'] ) && '' !== $post_fields['dtearsd_posttext'] ) ? $post_fields['dtearsd_posttext'] : null;

?>


<section id="banner-section"
        class="banner-section banner-deafult green-ctn center-align ctn-980" >
        <div class="wrapper">
          <h1 class="heading-1"><?php echo $dtearsd_posttitle; ?></h1>
          <?php if($dtearsd_posttext){
			echo html_entity_decode($dtearsd_posttext);
		  } ?>
		  <div class="thumb"> <?php the_post_thumbnail(
							'thumb_1200',
							array(
								'alt'   => get_the_title(),
								'title' => get_the_title(),
							)
						); ?> 
			</div>

			<div class="post-meta d-flex align-items-center justify-content-between">
				  <!-- /.post-tags -->
				  <?php if($dtearsd_post_categories){ ?>
					  <div class="post-cat">
						  <?php foreach ($dtearsd_post_categories as $category ) { ?>
							  <a href="<?php echo get_category_link($category); ?>"><?php echo $category->name; ?></a>
						  <?php } ?>
					  </div>
					  <!-- /.post-cat -->
				  <?php } ?>
				  <div class="post-shares">
					  <a href="http://www.facebook.com/sharer.php?u=<?php the_permalink();?>&amp;t=<?php the_title();?>" target="_blank"
						  rel="noopener" rel="noreferrer"
						  onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><img
							  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/facebook-icon.svg" alt="Facebook"
							  class="post-fb-share"></a>
					  <a href="http://www.linkedin.com/shareArticle?mini=true&amp;title=<?php the_title();?>&amp;url=<?php the_permalink();?>"
						  target="_blank" rel="noopener" rel="noreferrer"
						  onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><img
							  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/linkedin-icon.svg" alt="Linked In"
							  class="post-li-share"></a>
							  <a href="http://twitter.com/intent/tweet?text=Currently reading <?php the_title();?>&amp;url=<?php the_permalink();?>"
						  target="_blank" rel="noopener" rel="noreferrer"
						  onclick="javascript:window.open(this.href,'', 'menubar=no,toolbar=no,resizable=yes,scrollbars=yes,height=600,width=600');return false;"><img
							  src="<?php echo esc_url(get_template_directory_uri()); ?>/assets/img/twitter-icon.svg" alt="Twitter"
							  class="post-tw-share"></a>
				  </div>
				  <!-- /.post-shares -->
			  </div>

        </div>
      </section>

	  <div class="s-96"></div>
	  <div class="ctn-1400">
		  <div class="wrapper">
			  <div class="post-image">
			  </div><!-- .post-image -->
			  <article id="post-<?php the_ID(); ?>" <?php post_class('post-ctn'); ?>>
					  <?php get_template_part( 'partials/content' ); ?>
					  <div class="clear"></div>
					  <div class="post-details">
						  <div class="post-pagination"> <?php the_posts_pagination() ?> </div>
						  <div class="post-comments"> <?php
								  // If comments are open or we have at least one comment, load up the comment template.
								  if ( comments_open() || get_comments_number() ) {
									  comments_template();
								  }
							  ?>
						  </div>
					  </div>
				  </div>
	  
				  <?php
				  wp_reset_query();
				  wp_reset_postdata();
	  
				  $dtearsd_rp_selection_criteria = isset($fields['dtearsd_rp_selection_criteria']) ? $fields['dtearsd_rp_selection_criteria'] : null;
				  if($dtearsd_rp_selection_criteria == 'random'){
	  
					  $args = array(
						  'posts_per_page' => 3,
						  'post__not_in'   => array( $post->ID ),
						  'orderby'        => 'rand',
					  );
	  
					  $query = new WP_Query( $args );
	  
					  // The Loop
					  if ( $query->have_posts() ) {
						  while ( $query->have_posts() ) {
							  $query->the_post();
							  //Include specific template for the content.
							  get_template_part( 'partials/content', 'archive-post' );
						  }
					  ?> <div class="clear"></div> <?php
					  }
				  }
				  else {
					  global $post;
					  $dtearsd_selected_posts = array();
					  $dtearsd_selected_posts = isset($fields['dtearsd_rp_selected_posts']) ? $fields['dtearsd_rp_selected_posts'] : null;
					  if ( $dtearsd_selected_posts ) { ?> <div class="related-posts ">
					  <h3><?php _e( 'Related Posts', 'dtearsd_td' ) ?></h3> <?php
									  foreach ( $dtearsd_selected_posts as $dtearsd_post ) {
										  $post = $dtearsd_post;
										  setup_postdata( $post );
										  $pID         = $post->ID;
										  $post_fields = get_fields( $pID );
										  $custom_field  = $post_fields['custom_field'];
										  $src         = wp_get_attachment_image_src( get_post_thumbnail_id( $pID ), 'thumb_600', false );
										  if ( ! $src ) {
											  $src = get_template_directory_uri() . '/assets/img/defaults/default-image.webp';
										  } else {
											  $src = $src[0];
										  }
											  get_template_part( 'partials/content', 'archive-post' );
									  }
								  ?>
				  </div> <?php } wp_reset_query();
					  wp_reset_postdata();
					  }
					  ?>
			  </article>
		  </div>
	  </div>

