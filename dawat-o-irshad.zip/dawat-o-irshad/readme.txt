=== Dtearsd Package ===

Contributors: Abu Bakar
Tags: custom-menu, full-width-template, theme-options, translation-ready
Requires at least: 5.8
Tested up to: 5.8
Stable tag: 1.0.0

A Dtearsd Package WordPress theme

== Description ==

This is a Dtearsd Package WordPress theme
